<!DOCTYPE html>
<html>
<head>
    <title>Beranda</title>
</head>
<body>

<table border="1" width="100%" cellspacing="0">

<tr>
    <td colspan="2" align="center">
        <h1>TIKET TRAVEL ONLINE</h1>
    </td>
</tr>

<tr>

<!-- MENU -->
<td width="25%" height="700" align="center" valign="middle"
style="background-image:url('gambar2.jpg'); background-size:cover;">

    <p>
        <font size="10" face="Brush Script MT">
            <a href="beranda.php" style="color:white; text-decoration:none;">Beranda</a>
        </font>
    </p>

    <p>
        <font size="10" face="Brush Script MT">
            <a href="produk.php" style="color:white; text-decoration:none;">Produk</a>
        </font>
    </p>

    <p>
        <font size="10" face="Brush Script MT">
            <a href="kontak.php" style="color:white; text-decoration:none;">Kontak</a>
        </font>
    </p>

    <p>
        <font size="10" face="Brush Script MT">
            <a href="index.php" style="color:white; text-decoration:none;">Pendaftaran</a>
        </font>
    </p>
    <p>
    <font size="10" face="Brush Script MT">
        <a href="tampil.php" style="color:white; text-decoration:none;">
            Data Mahasiswa
        </a>
    </font>
</p>
</td>

<!-- ISI -->
<td align="center"
style="background-image:url('gambar1.jpg'); background-size:cover;">

    <font face="Times New Roman" color="white">
        <h2>HALAMAN BERANDA</h2>
        <h3>Selamat datang di layanan pemesanan tiket travel online</h3>
    </font>

</td>

</tr>

</table>

</body>
</html>