<!DOCTYPE html>
<html>
<head>
    <title>Kontak</title>
</head>
<body>

<table border="1" width="100%" cellspacing="0">

<tr>
    <td colspan="2" align="center">
        <h1>TIKET TRAVEL ONLINE</h1>
    </td>
</tr>

<tr>

<!-- MENU -->
<td width="25%" height="700" align="center" valign="middle"
style="background-image:url('gambar2.jpg'); background-size:cover;">

    <p>
        <font size="10" face="Brush Script MT">
            <a href="beranda.php" style="color:white; text-decoration:none;">Beranda</a>
        </font>
    </p>

    <p>
        <font size="10" face="Brush Script MT">
            <a href="produk.php" style="color:white; text-decoration:none;">Produk</a>
        </font>
    </p>

    <p>
        <font size="10" face="Brush Script MT">
            <a href="kontak.php" style="color:white; text-decoration:none;">Kontak</a>
        </font>
    </p>

    <p>
        <font size="10" face="Brush Script MT">
            <a href="index.php" style="color:white; text-decoration:none;">Pendaftaran</a>
        </font>
    </p>

</td>

<!-- ISI -->
<td align="center"
style="background-image:url('gambar1.jpg'); background-size:cover;">

    <font face="Times New Roman" color="white">

    <h2>HALAMAN KONTAK</h2>

    <h3>TransTravel</h3>

    <p>Jl. Mojopahit Tuban</p>

    <p>WhatsApp : 085895966370</p>

    </font>

</td>

</tr>

</table>

</body>
</html>